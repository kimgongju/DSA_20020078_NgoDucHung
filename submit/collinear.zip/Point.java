import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;

import java.util.Comparator;

public class Point implements Comparable<Point> {
    private final int x;
    private final int y;


    // constructs the point (x, y)
    public Point(int x, int y) {
        /* DO NOT MODIFY */
        this.x = x;
        this.y = y;
    }

    // draws this point
    public void draw() {
        /* DO NOT MODIFY */
        StdDraw.point(x, y);
    }

    // draws the line segment from this point to that point
    public void drawTo(Point that) {
        /* DO NOT MODIFY */
        StdDraw.line(this.x, this.y, that.x, that.y);
    }


    // string representation
    public String toString() {
        /* DO NOT MODIFY */
        return "(" + x + ", " + y + ")";
    }

    // compare two points by y-coordinates, breaking ties by x-coordinates
    public int compareTo(Point that) {
        // sap xep theo do cao y -> theo x
        if (this.y != that.y)
            return this.y - that.y;
        return this.x - that.x;
    }

    // the slope between this point and that point
    public double slopeTo(Point that) {
        if (x == that.x && y == that.y)
            return Double.NEGATIVE_INFINITY;
        else if (x == that.x)
            return Double.POSITIVE_INFINITY;
        else if (y == that.y)
            return 0;
        else return 1.0 * (that.y - y) / (that.x - x);
    }

    // compare two points by slopes they make with this point
    public Comparator<Point> slopeOrder() {
        return new Comparator<Point>() {
            private final int temp = 1000000;
            @Override
            public int compare(Point o1, Point o2) {
                return (int) (temp * (Point.this.slopeTo(o1) - Point.this.slopeTo(o2)));
            }
        };
    }

    public static void main(String[] args) {

        Point p = new Point(326, 310);
        Point q = new Point(43, 183);
        Point r = new Point(98, 42);
//        Point s = new Point(21936, 26019);
        System.out.println(p.slopeOrder().compare(q, r));
        System.out.println(p.slopeTo(q));
        System.out.println(p.slopeTo(r));
        System.out.println(p.slopeTo(q) - p.slopeTo(r));
        System.out.println((int) (p.slopeTo(q) - p.slopeTo(r)));


//        System.out.println(p.slopeOrder().compare(r, s));
//        System.out.println(p.slopeOrder().compare(q, s));


        // read the n points from a file
        In in = new In();
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point c : points) {
            c.draw();
        }



        StdDraw.show();
/*
6
19000  10000
18000  10000
32000  10000
21000  10000
 1234   5678
14000  10000
 */
        // print and draw the line segments
//        FastCollinearPoints collinear = new FastCollinearPoints(points);
//        for (LineSegment segment : collinear.segments()) {
//            StdOut.println(segment);
//            segment.draw();
//        }
//        StdDraw.show();
    }

}
