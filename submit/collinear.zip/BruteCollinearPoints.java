import java.util.Arrays;

public class BruteCollinearPoints {
    private final LineSegment[] segments;

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] pointsIn) {
        if (pointsIn == null)
            throw new IllegalArgumentException();

        // kiem tra point[i] co null khong
        for (int i = 0; i < pointsIn.length; i++) {
            if (pointsIn[i] == null)
                throw new IllegalArgumentException();
        }

        // kiem tra co point[i] nao trung nhau khong
        for (int i = 0; i < pointsIn.length; i++) {
            for (int j = i + 1; j < pointsIn.length; j++)
                if (pointsIn[i].compareTo(pointsIn[j]) == 0)
                    throw new IllegalArgumentException();
        }

        Point[] points = new Point[pointsIn.length];
        for (int i = 0; i < pointsIn.length; i++)
            points[i] = pointsIn[i];

        Arrays.sort(points);
        int length = points.length;
        // tao temp[] de giam bo nho cho segment
        LineSegment[] temp = new LineSegment[length * length + 1];
        int cnt = 0;

        // co the for lan luot nhu the nay do da sap xep mang
        for (int p1 = 0; p1 < length; p1++) {
            for (int p2 = p1 + 1; p2 < length; p2++) {
                for (int p3 = p2 + 1; p3 < length; p3++) {
                    for (int p4 = p3 + 1; p4 < length; p4++) {
                        // Nếu p1, p2, p3 nam tren duong thang và p2, p3, p4 nam tren duong thang
                        // Do da sap xep nen p1, p2, p3, p4 luon nam theo dung thu tu (p1,p2,p3,p4) hoac (p4,p3,p2,p1)
                        if (points[p1].slopeTo(points[p2]) == points[p2].slopeTo(points[p3])
                                && points[p2].slopeTo(points[p3]) == points[p3].slopeTo(points[p4])) {
                            temp[cnt++] = new LineSegment(points[p1], points[p4]);
                        }
                    }
                }
            }
        }

        // copy lai
        segments = new LineSegment[cnt];
        for (int i = 0; i < cnt; i++)
            segments[i] = temp[i];

    }

    // the number of line segments
    public int numberOfSegments() {
        return segments.length;
    }

    // the line segments
    public LineSegment[] segments() {
        LineSegment[] temp = new LineSegment[this.segments.length];
        for (int i = 0; i < this.segments.length; i++)
            temp[i] = this.segments[i];
        return temp;
    }
}
