import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;

public class FastCollinearPoints {
    private final LineSegment[] segments;

    // finds all line segments containing 4 or more points
    // cac segment chua >= 4 diem chi duoc return diem dau va diem cuoi
    public FastCollinearPoints(Point[] pointsIn) {
        if (pointsIn == null)
            throw new IllegalArgumentException();

        for (int i = 0; i < pointsIn.length; i++)
            if (pointsIn[i] == null)
                throw new IllegalArgumentException();

        // 2 phan tu phai khac nhau
        for (int i = 0; i < pointsIn.length; i++)
            for (int j = i + 1; j < pointsIn.length; j++)
                if (pointsIn[i].compareTo(pointsIn[j]) == 0)
                    throw new IllegalArgumentException();

        int length = pointsIn.length;

        Point[] points = new Point[length];
        for (int i = 0; i < length; i++)
            points[i] = pointsIn[i];

        Arrays.sort(points);
        // copy
        Point[] tmp = new Point[length];
        for (int i = 0; i < length; i++)
            tmp[i] = points[i];
        
        LineSegment[] tempStorage = new LineSegment[length * length + 1];

        int cnt = 0;

        // do doc cua origin voi mot diem duoc chon
        double slopeValue;

        // origin luon la diem duoi cung
        Point origin;

        for (int i = 0; i < length; i++) {
            // chon goc
            origin = points[i];

            // sort theo toa do de lam cho cac toa do duoc sap xep tu tren xuong duoi, tu phai sang trai
            Arrays.sort(tmp);
            // sort theo do doc, vi da duoc sort theo toa do
            // nen cac diem duoc xep theo do doc va theo compareTo cua Points
            // cac diem cung do doc se canh nhau
            Arrays.sort(tmp, origin.slopeOrder());      // x x x x y y y y y z z z z
            int j = 0;

            // so luong point lien tiep (tru diem dau tien do tan dung bo nho (thay lam bien dem))
            int cntPoint = 0;

            while (j < length - 2) {
                // Slopevalue voi other point q
                slopeValue = origin.slopeTo(tmp[j]);

                // cnt chua diem j
                cntPoint = 1;

                // dem co bao nhieu diem lien tiep (cung do doc)
                // luc day minh se lay duoc x x x x
                while (j + cntPoint < length && slopeValue == origin.slopeTo(tmp[j + cntPoint])) {
                    cntPoint++;
                }

                cntPoint -= 1; // while cuoi van ++ nen phai -1

                if (cntPoint >= 2) {
                    if (origin.compareTo(tmp[j]) < 0 && origin.compareTo(tmp[j + cntPoint]) < 0) {
                        // them vao LineSegment[] segments
                        tempStorage[cnt] = new LineSegment(origin, tmp[j + cntPoint]);
                        cnt++;
                    }
                    // chuyen sang vi tri y (khong lien tiep voi x)
                    j = j + cntPoint;
                }
                // do luc dau j = 0 => 2 diem trung => phai dich j sang
                j++;
            }
        }
        segments = new LineSegment[cnt];
        for (int i = 0; i < cnt; i++) {
            segments[i] = tempStorage[i];
        }
    }

    // the number of line segments
    public int numberOfSegments() {
        return segments().length;
    }

    // the line segments
    public LineSegment[] segments() {
        LineSegment[] temp = new LineSegment[this.segments.length];
        for (int i = 0; i < segments.length; i++)
            temp[i] = this.segments[i];
        return temp;
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In();
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
//            p.draw(i);
            p.draw();
//            i++;
        }
//        StdDraw.show();
//        int i = 0;
//      for (Point p : points) {
//          p.draw(i);
////          p.draw();
//          i++;
//      }
        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
//        6
//        19000  10000
//        18000  10000
//        32000  10000
//        21000  10000
//        1234   5678
//        14000  10000
//        14000  15000
//        6000   7000
//        8
//        10000 0
//        0  10000
//        3000   7000
//        7000   3000
//        20000  21000
//        3000   4000
    }

}