import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;


public class PercolationStats {
    private final double mean;
    private final double stddev;
    private final double confidenceLo;
    private final double confidenceHi;

    // perform trials independent experiments on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException();
        }
        final double TEMP = 1.96;
        double[] ans = new double[trials];
        for (int i = 0; i < trials; i++) {

            Percolation percolation = new Percolation(n);
            // cho den khi nao percolates
            while (!percolation.percolates()) {
                int row = StdRandom.uniform(n) + 1;
                int col = StdRandom.uniform(n) + 1;
                if (!percolation.isOpen(row, col)) {
                    percolation.open(row, col);
                }
            }
            // ty le o duoc mo / n * n
            ans[i] = 1.0 * percolation.numberOfOpenSites() / (n * n);
        }

        mean = StdStats.mean(ans);
        stddev = StdStats.stddev(ans);
        confidenceLo = mean - (TEMP * stddev) / Math.sqrt(trials);
        confidenceHi = mean + (TEMP * stddev) / Math.sqrt(trials);
    }

    // Sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // Sample standard deviation of percolation threshold
    public double stddev() {
        return stddev;
    }

    // Low endpoint of 95% confidence interval
    public double confidenceLo() {
        return confidenceLo;
    }

    // High endpoint of 95% confidence interval
    public double confidenceHi() {
        return confidenceHi;
    }

    // test client (see below)
    public static void main(String[] args) {
        int n      = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        PercolationStats percolationStats = new PercolationStats(n, t);
        System.out.println("mean = " + percolationStats.mean());
        System.out.println("stddev = " + percolationStats.stddev());
        System.out.println("95% confidence interval = [" + percolationStats.confidenceLo() + ", " + percolationStats.confidenceHi() + "]");
    }
}