import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private boolean[][] site;
    private final WeightedQuickUnionUF grid;
    private final WeightedQuickUnionUF tempGrid;
    private final int n;
    private int openSites;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException();
        // mang bat dau tu 1 1 va ket thuc n n, 0 la top, n * n + 1 la bottom
        grid = new WeightedQuickUnionUF(n * n + 2);

        // khong bao gom bottom
        tempGrid = new WeightedQuickUnionUF(n * n + 1);
        site = new boolean[n + 1][n + 1]; // khong bao gom top va bottom
        this.n = n;
        openSites = 0;
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        isValid(row, col);
        if (site[row][col])
            return;
        site[row][col] = true;
        //        for(int i = 1; i <= 3; i++) {
        //            for(int j = 1; j <= 3; j++)
        //                System.out.print(site[i][j] + " ");
        //            System.out.println();
        //        }
        openSites++;
        if (row == 1) {
            grid.union(hashCode(row, col), 0);
            tempGrid.union(hashCode(row, col), 0);
        }
        if (row == n) {
            grid.union(hashCode(row, col), n * n + 1);
        }
        // union ben tren
        if (row > 1 && isOpen(row - 1, col)) {
            grid.union(hashCode(row, col), hashCode(row - 1, col));
            tempGrid.union(hashCode(row, col), hashCode(row - 1, col));
        }
        // union ben duoi
        if (row < n && isOpen(row + 1, col)) {
            grid.union(hashCode(row, col), hashCode(row + 1, col));
            tempGrid.union(hashCode(row, col), hashCode(row + 1, col));
        }
        // union ben trai
        if (col > 1 && isOpen(row, col - 1)) {
            grid.union(hashCode(row, col), hashCode(row, col - 1));
            tempGrid.union(hashCode(row, col), hashCode(row, col - 1));
        }
        // union ben phai
        if (col < n && isOpen(row, col + 1)) {
            grid.union(hashCode(row, col), hashCode(row, col + 1));
            tempGrid.union(hashCode(row, col), hashCode(row, col + 1));
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        isValid(row, col);
        return site[row][col];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        isValid(row, col);
        if (!isOpen(row, col)) {
            return false;
        }
        return tempGrid.find(0) == tempGrid.find(hashCode(row, col));
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return grid.find(0) == grid.find(n * n + 1);
    }

    private void isValid(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n) {
            throw new IllegalArgumentException();
        }
    }

    // Hash
    private int hashCode(int row, int col) {
        isValid(row, col);
        return (row - 1) * n + col;
    }

    // test client (optional)
    public static void main(String[] args) {
        //                Percolation percolation = new Percolation(3);
        //                percolation.open(1, 3);
        //                System.out.println(percolation.isFull(3, 1));
        //
        //                percolation.open(2, 3);
        //        System.out.println(percolation.isFull(3, 1));
        ////                System.out.println(percolation.percolates());
        //                percolation.open(3, 3);
        //        System.out.println(percolation.isFull(3, 1));
        ////                System.out.println(percolation.percolates());
        //                percolation.open(3, 1);
        //        System.out.println(percolation.isFull(3, 1));
        ////                System.out.println(percolation.percolates());
        //                percolation.open(2, 1);
        //        System.out.println(percolation.isFull(3, 1));
        ////                System.out.println(percolation.percolates());
        //                percolation.open(1, 1);
        //                System.out.println(percolation.percolates());
    }
}