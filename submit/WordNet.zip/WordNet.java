import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.DirectedCycle;
import edu.princeton.cs.algs4.In;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WordNet {
    // map luu tru synsets easy to search id, (mot synset co the thuoc nhieu id)
    private final Map<String, List<Integer>> synsets = new HashMap<>();
    // mang danh dau va co the return Iterator<String> cho tat ca nouns
    private final List<String> nouns = new ArrayList<>();
    // edges: edge noi voi nhung canh nao (Directed graph)
//    private final Map<Integer, ArrayList<Integer>> edges = new HashMap<Integer, ArrayList<Integer>>();
    private int size = 0;
    private final Digraph graph;

    private final SAP sap;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null)
            throw new IllegalArgumentException();

        synsetIn(synsets);

        // tao graph
        graph = new Digraph(size);

        hypernymsIn(hypernyms);
        sap = new SAP(graph);

        // kiem tra co chu trinh hay khong
        if (hasCycle(graph)) {
            throw new IllegalArgumentException();
        }
    }

    private void synsetIn(String path) {
        In in = new In(path);
        String string;
        while (in.hasNextLine()) {
            string = in.readLine();
            String[] bigPart = string.split(","); // 3 phan tu: id; all synsets; gloss
            String[] words = bigPart[1].split(" "); // cac synsets duoc tach ra
            nouns.add(bigPart[1]);
            for (String word: words) {
                if (synsets.get(word) == null) { // chua duoc khoi tao
                    synsets.put(word, new ArrayList<>());       // tao
                }
                synsets.get(word).add(Integer.parseInt(bigPart[0]));    // them id vao
            }
            size++;
        }
    }

    private void hypernymsIn(String path) {
        In in = new In(path);
        String string;
        int cnt = 0;
        while (in.hasNextLine()) {
            string = in.readLine();
            String[] bigPart = string.split(",");   // [0] = x, [1 -> length-1] = y, x -> y (edges)
            for (int i = 1; i < bigPart.length; i++) {
                // them canh vao graph
                graph.addEdge(Integer.parseInt(bigPart[0]), Integer.parseInt(bigPart[i]));
            }
            cnt++;
        }
        if (size - cnt > 1)
            throw new IllegalArgumentException();
    }

//     returns all WordNet nouns
    public Iterable<String> nouns() {
//        return nouns;
        return synsets.keySet();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null)
            throw new IllegalArgumentException();
        return synsets.containsKey(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        if (!isNoun(nounA) || !isNoun(nounB))
            throw new IllegalArgumentException();
        return sap.length(synsets.get(nounA), synsets.get(nounB));
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        if (!isNoun(nounA) || !isNoun(nounB))
            throw new IllegalArgumentException();
        return nouns.get(sap.ancestor(synsets.get(nounA), synsets.get(nounB)));
    }

    private boolean hasCycle(Digraph digraph) {
        return new DirectedCycle(digraph).hasCycle();
    }
    // do unit testing of this class
    public static void main(String[] args) {
//        In in = new In();
//        String string = in.readLine();
//        String[] firstPart = string.split(","); // 3 phan tu, phan dau la id, phan 2 la noun, phan 3 la gloss
//        String[] secondPart = firstPart[0].split(" ");
//        System.out.println(firstPart);
//        System.out.println();
//        System.out.println(secondPart);
    }
}
