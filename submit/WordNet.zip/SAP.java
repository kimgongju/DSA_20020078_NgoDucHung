import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

/**
 * Class nay tim duong di ngan nhat giua 2 dinh va tim cha chung gan nhat
 */
public class SAP {
    private final Digraph digraph;
    // constructor takes a digraph (not necessarily a DAG)
    public SAP(Digraph G) {
        if (G == null)
            throw new IllegalArgumentException();

        digraph = new Digraph(G);
    }

    // length of shortest ancestral path between v and w; -1 if no such path
    public int length(int v, int w) {
        isValid(v);
        isValid(w);
        return new BFS(digraph, v, w).length;
    }

    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor(int v, int w) {
        return new BFS(digraph, v, w).getAncestor();
    }

    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        return new BFS(digraph, v, w).getLength();
    }

    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        return new BFS(digraph, v, w).getAncestor();
    }

    private void isValid(int v) {
        if (v >= digraph.V())
            throw new IllegalArgumentException();
    }

//    private void isValid(Iterable<Integer> vs) {
//        for (Integer v: vs)
//            isValid(v);
//    }
    private static class BFS {

        private final Digraph digraph;
        private final BreadthFirstDirectedPaths x; // luu tru duong di tu x toi cac dinh khac
        private final BreadthFirstDirectedPaths y; // luu tru duong di tu y toi cac dinh khac
        private int length = Integer.MAX_VALUE;
        private int ancestor = -1;
        BFS(Digraph digraph, int x, int y) {
            if (digraph.V() == 0)
                throw new IllegalArgumentException();
            this.digraph = digraph;
            this.x = new BreadthFirstDirectedPaths(digraph, x);
            this.y = new BreadthFirstDirectedPaths(digraph, y);
            findAncestor();
        }

        BFS(Digraph digraph, Iterable<Integer> x, Iterable<Integer> y) {
            if (digraph.V() == 0)
                throw new IllegalArgumentException();
            this.digraph = digraph;
            this.x = new BreadthFirstDirectedPaths(digraph, x);
            this.y = new BreadthFirstDirectedPaths(digraph, y);
            findAncestor();
        }

        private boolean isAncestor(int i) {
            return x.hasPathTo(i) && y.hasPathTo(i);
        }

        private int pathLen(int i) {    // Khoang cach giua 2 node = khoang cach tu node 1 -> cha gan nhat
                                        // + khoang cach tu node 2 -> cha gan nhat
            return x.distTo(i) + y.distTo(i);
        }

        private void findAncestor() { // Tim cha cua 2 nut bang cac for tat ca cac nut
            for (int i = 0; i < digraph.V(); i++) {
                if (isAncestor(i))
                    if (length > pathLen(i)) {
                        length = pathLen(i);
                        ancestor = i;
                    }
            }
            if (length == Integer.MAX_VALUE)
                length = -1;
        }

        public int getAncestor() {
            return ancestor;
        }

        public int getLength() {
            return length;
        }
    }


    // do unit testing of this class
    public static void main(String[] args) {
        In in = new In(args[0]);
        Digraph G = new Digraph(in);
        SAP sap = new SAP(G);
        while (!StdIn.isEmpty()) {
            int v = StdIn.readInt();
            int w = StdIn.readInt();
            int length   = sap.length(v, w);
            int ancestor = sap.ancestor(v, w);
            StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
        }
    }

}
