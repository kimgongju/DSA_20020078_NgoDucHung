import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;

public class Permutation {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        String s;
        RandomizedQueue<String> randomizedQueue = new RandomizedQueue<>();
        while (!StdIn.isEmpty()) {
            s = StdIn.readString();
            randomizedQueue.enqueue(s);
        }

        Iterator<String> it = randomizedQueue.iterator();
        for (int i = 0; i < n; i++) {
            if (it.hasNext()) {
                StdOut.println(it.next());
            }
        }
    }
}
