import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] data;
    private int n;

    // construct an empty randomized queue
    public RandomizedQueue() {
        n = 0;
        data = (Item[]) new Object[1];
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return n == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return n;
    }

    // add the item
    public void enqueue(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        data[n++] = item;
        if (n == data.length) {
            Item[] temp = (Item[]) new Object[2 * data.length];
            System.arraycopy(data, 0, temp, 0, n);
            data = temp;
        }
    }

    // remove and return a random item
    public Item dequeue() {
        if (isEmpty()) {
            throw new java.util.NoSuchElementException();
        }
        int rand = StdRandom.uniform(n);
        Item item = data[rand];
        data[rand] = data[n - 1];
        data[n - 1] = null;
        n--;
	if (n > 0 && n == data.length / 4) {
	    Item[] temp = (Item[]) new Object[data.length / 2];
            System.arraycopy(data, 0, temp, 0, n);
            data = temp;
	}
        return item;
    }

    // return a random item (but do not remove it)
    public Item sample() {
        if (isEmpty()) {
            throw new java.util.NoSuchElementException();
        }
        int rand = StdRandom.uniform(n);
        return data[rand];
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new LinkedIterator();
    }

    private class LinkedIterator implements Iterator<Item> {
        private int i = n;
        private final int[] order;

        public LinkedIterator() {
            // mang thay doi thu tu cua array (gia tri order[i] la id cua data)
            order = new int[i];
            for (int k = 0; k < i; k++) {
                order[k] = k;
            }
            StdRandom.shuffle(order);
        }

        public boolean hasNext() {
            return i > 0;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Item next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException();
            }
            return data[order[--i]];
        }
    }

    // unit testing (required)
    public static void main(String[] args) {
        // haven't done
    }

}
